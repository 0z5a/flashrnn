"""Run the pinned portable CUDA gate in one granted H20 window."""

import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parent
assert root == Path("/root/autodl-tmp/0z5a/flashrnn2-h20-portable-r3")
assert sys.executable == "/root/autodl-tmp/0z5a/flashns-baselines-region42-35679-20261006/.venv/bin/python"
manifest = json.loads((root / "manifest.json").read_text())
assert (
    Path("/proc/sys/kernel/random/boot_id").read_text().strip() == manifest["boot_id"]
)
output = root / "evidence"
output.mkdir()
receipt = output / "controller.json"
record = {
    "status": "PRECHECK",
    "controller_pid": os.getpid(),
    "started": time.time(),
    "scope": manifest["scope"],
    "source_commit": manifest["source_commit"],
    "manifest_sha256": hashlib.sha256(
        (root / "manifest.json").read_bytes()
    ).hexdigest(),
    "performance_claim": False,
}
receipt.write_text(json.dumps(record, indent=2) + "\n")
locks = Path("/root/autodl-tmp/0z5a-coordination/h20")
with (locks / "gpu0.lock").open("r") as gpu, (locks / "io.lock").open("r") as io:
    for handle, identity in zip((gpu, io), manifest["locks"], strict=True):
        stat = os.fstat(handle.fileno())
        assert (stat.st_dev, stat.st_ino) == (identity["device"], identity["inode"])
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for name, entry in manifest["files"].items():
        path = root / name
        assert path.stat().st_size == entry["bytes"]
        with path.open("rb") as handle:
            assert hashlib.file_digest(handle, "sha256").hexdigest() == entry["sha256"]
    hardware = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=uuid,name,driver_version", "--format=csv,noheader"],
        text=True,
    ).strip()
    assert hardware == manifest["gpu_identity"]
    compute = subprocess.check_output(
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader,nounits"],
        text=True,
    ).strip()
    assert not compute, compute
    record.update(status="ADMITTED", admitted=time.time(), hardware=hardware)
    receipt.write_text(json.dumps(record, indent=2) + "\n")
    command = [
        sys.executable,
        str(root / "application/tools/flashrnn2/portable_gate.py"),
        "--device",
        "cuda:0",
        "--config",
        str(root / "application/tools/flashrnn2/portable-small.json"),
        "--output",
        str(output / "portable-cuda-r3.jsonl"),
    ]
    env = dict(
        os.environ,
        PYTHONPATH=str(root / "application"),
        PYTHONDONTWRITEBYTECODE="1",
        OMP_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        CUDA_VISIBLE_DEVICES="0",
    )
    with (output / "gate.log").open("x") as log:
        child = subprocess.Popen(
            command,
            cwd=root / "application",
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
        )
        record.update(status="RUNNING", child_pid=child.pid, command=command)
        receipt.write_text(json.dumps(record, indent=2) + "\n")
        record["returncode"] = child.wait()
    record.update(status="CHILD_EXITED", child_finished=time.time())
    receipt.write_text(json.dumps(record, indent=2) + "\n")
record.update(status="LOCKS_RELEASED", finished=time.time())
receipt.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record), flush=True)
raise SystemExit(record["returncode"])
