"""Machine-local serial queue; adopt healthy controllers and launch admitted actions.

Uses only the standard library. Never signals, restarts, retries, or modifies
an environment. A completed step must receive its verified offbox handback
before its successor can run. Each launch requires a fresh broker grant.
"""
import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def identity(pid):
    return {'pid': pid, 'start_ticks': int(Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()[19])}


def terminal_state(spec):
    root = Path(spec['root'])
    label = spec['label']
    launch_path = root / (label + '-launch.json')
    if not launch_path.exists():
        return 'not_started', {}
    launch = read(launch_path)
    terminal_path = root / (label + '-exit.json')
    if not terminal_path.exists():
        for actor in [launch['wrapper'], launch['controller']]:
            path = Path(f"/proc/{actor['pid']}/stat")
            if path.exists() and identity(actor['pid']) == {k: actor[k] for k in ['pid', 'start_ticks']}:
                return 'running', {'launch': launch}
        return 'unknown_missing_terminal', {'launch': launch}
    terminal = read(terminal_path)
    status = read(root / spec['status_relative'])
    if spec.get('kind') == 'flashrnn2_portable':
        actors = [terminal['wrapper'], terminal['controller'], {'pid': status['child_pid']}]
        if any(Path(f"/proc/{actor['pid']}").exists() for actor in actors):
            return 'awaiting_owned_exit', {'terminal': terminal}
        if terminal['actual_exit_code'] != 0 or status['returncode'] != 0 or status['status'] != 'LOCKS_RELEASED':
            return 'failed', {'terminal': terminal, 'state': status['status']}
        return 'awaiting_offbox_handback', {'terminal': terminal, 'children': 1, 'scope': '38-case CUDA correctness only'}
    actors = [terminal['wrapper'], terminal['controller']] + [job['child'] for job in status['jobs']]
    if any(Path(f"/proc/{actor['pid']}").exists() for actor in actors):
        return 'awaiting_owned_exit', {'terminal': terminal}
    if terminal['actual_exit_code'] != 0 or status['controller_exit_code'] != 0:
        return 'failed', {'terminal': terminal, 'state': status['state']}
    if status['state'] != 'completed' or any(job['exit_code'] != 0 for job in status['jobs']):
        return 'failed', {'terminal': terminal, 'state': status['state']}
    return 'awaiting_offbox_handback', {'terminal': terminal, 'children': len(status['jobs'])}


def handback_ok(directory, job, spec, binding):
    path = directory / (job['id'] + '-whole.json')
    if not path.exists():
        return False
    handback = read(path)
    assert handback['resource_binding'] == binding
    assert handback['label'] == spec['label']
    receipt_path = directory / handback['receipt_filename']
    assert digest(receipt_path) == handback['completion_sha256']
    receipt = read(receipt_path)
    assert receipt['state'] == 'WHOLE_WINDOW_HANDBACK'
    assert receipt['actual_controller_exit_code'] == receipt['finalizer_actual_exit_code'] == 0
    assert receipt['all_owned_processes_independently_absent'] and receipt['finalizer_independently_absent']
    assert handback['independent_numerical_audit_passed'] and handback['fresh_clear_passed']
    for key in ['summary', 'clear']:
        assert digest(directory / handback[key + '_filename']) == handback[key + '_sha256']
    clear = read(directory / handback['clear_filename'])
    assert clear['boot_id'] == binding['boot_id'] and clear['gpu_uuid'] == binding['gpu_uuid']
    assert clear['actual_check_exit_code'] == 0 and clear['compute_apps'] == []
    return True


def activation_ok(directory, job, binding, queue_sha):
    path = directory / (job['id'] + '-activation.json')
    if not path.exists():
        return None
    activation = read(path)
    assert activation['resource_binding'] == binding
    assert activation['queue_sha256'] == queue_sha
    assert activation['job_id'] == job['id']
    grant_path = directory / activation['grant_filename']
    assert digest(grant_path) == activation['grant_sha256']
    grant = read(grant_path)
    assert grant['state'] == 'NEW_FINITE_WINDOW_GRANTED'
    assert grant['gpu_uuid'] == binding['gpu_uuid'] and grant['boot_id'] == binding['boot_id']
    assert time.time() < grant['admission_expires_unix'], 'activation expired; no retry'
    assert grant['supervisor_queue_sha256'] == queue_sha
    assert grant['supervisor_job_id'] == job['id']
    assert grant['supervisor_action_sha256'] == activation['action_sha256']
    assert grant['broker_thread'] == '01a10839-8042-7072-b744-1e54b8421800'
    script = directory / activation['action_filename']
    assert script.is_file() and not script.is_symlink()
    assert digest(script) == activation['action_sha256']
    spec = activation['controller_spec']
    for key, value in job['expected_controller_spec'].items():
        assert spec[key] == value
    assert grant['maximum_gpu_children'] == job['maximum_gpu_children']
    assert grant['packet_sha256'] == job['packet_sha256']
    assert grant['source_commit'] == job['source_commit']
    assert spec['root'] == grant['remote_root']
    assert spec['label'] == activation['label']
    assert not (Path(spec['root']) / (spec['label'] + '-launch.json')).exists()
    assert not (Path(spec['root']) / (spec['label'] + '-exit.json')).exists()
    return activation


def fresh_resource(binding):
    assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == binding['boot_id']
    assert subprocess.check_output(['nvidia-smi', '--query-gpu=uuid', '--format=csv,noheader'], text=True).strip() == binding['gpu_uuid']
    descriptors = []
    try:
        for name, inode in zip(['gpu0.lock', 'io.lock'], binding['lock_inodes']):
            descriptor = os.open('/root/autodl-tmp/0z5a-coordination/h20/' + name, os.O_RDWR)
            descriptors.append(descriptor)
            stat = os.fstat(descriptor)
            assert (stat.st_dev, stat.st_ino) == (binding['lock_device'], inode)
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert not subprocess.check_output(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'], text=True).strip()
    finally:
        for descriptor in reversed(descriptors):
            os.close(descriptor)


def run(directory):
    queue_path = directory / 'queue.json'
    queue = read(queue_path)
    queue_sha = digest(queue_path)
    assert len({job['id'] for job in queue['jobs']}) == len(queue['jobs'])
    binding = queue['resource_binding']
    lock = os.open(directory / 'supervisor.lock', os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    state_path = directory / 'status.json'
    assert not state_path.exists(), 'refuse second supervisor or automatic restart'
    state = {'state': 'running', 'supervisor': identity(os.getpid()), 'started_unix': time.time(),
             'queue_sha256': queue_sha, 'resource_binding': binding, 'jobs': []}
    write(directory / 'launch.json', state)
    last = None
    for job in queue['jobs']:
        row = {'id': job['id'], 'name': job['name'], 'state': 'queued'}
        state['jobs'].append(row)
        spec = job.get('adopt')
        action = None
        while True:
            assert digest(queue_path) == queue_sha, 'immutable queue changed'
            assert Path('/proc/sys/kernel/random/boot_id').read_text().strip() == binding['boot_id']
            if spec is None:
                activation = activation_ok(directory, job, binding, queue_sha)
                if activation is None:
                    row['state'] = 'awaiting_fresh_activation'
                else:
                    fresh_resource(binding)
                    write(directory / (job['id'] + '-consumed.json'), {'activation_sha256': digest(directory / (job['id'] + '-activation.json')), 'started_unix': time.time()})
                    assert not (directory / (job['id'] + '-action.log')).exists()
                    with (directory / (job['id'] + '-action.log')).open('x') as output:
                        action = subprocess.Popen([sys.executable, str(directory / activation['action_filename'])], cwd=directory,
                                                  stdout=output, stderr=subprocess.STDOUT)
                        row['action_pid'] = action.pid
                        row['action_actual_exit_code'] = action.wait()  # no timeout or signals
                    if row['action_actual_exit_code'] != 0:
                        raise RuntimeError('single action failed; do not retry')
                    spec = activation['controller_spec']
            if spec is not None:
                row['state'], details = terminal_state(spec)
                row['details'] = details
                if row['state'] in ['failed', 'unknown_missing_terminal', 'not_started']:
                    raise RuntimeError('controller failed or unknown; preserve queue and do not retry')
                if row['state'] == 'awaiting_offbox_handback' and handback_ok(directory, job, spec, binding):
                    row['state'] = 'whole_handed_back'
                    row['finished_unix'] = time.time()
                    write(state_path, state)
                    print(json.dumps({'timestamp': time.time(), 'job': row}), flush=True)
                    break
            key = (job['id'], row['state'])
            state['updated_unix'] = time.time()
            write(state_path, state)
            if key != last:
                print(json.dumps({'timestamp': time.time(), 'job': row}), flush=True)
                last = key
            time.sleep(queue['poll_seconds'])
    state.update(state='completed', finished_unix=time.time(), actual_exit_code=0)
    write(state_path, state)
    write(directory / 'exit.json', state)
    os.close(lock)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    try:
        run(args.root)
    except Exception as error:
        failure = {'state': 'failed', 'actual_exit_code': 1, 'finished_unix': time.time(), 'error': repr(error)}
        write(args.root / 'failure.json', failure)
        print(json.dumps(failure), flush=True)
        raise
