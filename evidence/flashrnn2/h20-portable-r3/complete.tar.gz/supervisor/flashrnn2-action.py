"""One-time FlashRNN2 action invoked only by the existing H20 supervisor."""

import hashlib
import json
import os
import subprocess
import time
from pathlib import Path


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


supervisor = Path(__file__).resolve().parent
machine_root = Path("/root/autodl-tmp/0z5a")
root = machine_root / "flashrnn2-h20-portable-r3"
archive = machine_root / "h20-portable-r3-current.tar.gz"
wrapper = (
    machine_root / "flashns-baselines-region42-35679-20261006/natural_exit_wrapper.py"
)
runtime = machine_root / "flashns-baselines-region42-35679-20261006/.venv/bin/python"
label = "flashrnn2-portable-r3"
queue_path = supervisor / "queue.json"
queue = json.loads(queue_path.read_text())
job = queue["jobs"][2]
binding = queue["resource_binding"]
grant = json.loads((supervisor / "flashrnn2-grant.json").read_text())
spec = job["expected_controller_spec"]

assert (
    sha256(queue_path)
    == "a4d04ef91382c22d808340422798de02d49fed2edc8700462f9652659aaac877"
)
assert job["id"] == grant["supervisor_job_id"] == "flashrnn2"
assert grant["state"] == "NEW_FINITE_WINDOW_GRANTED"
assert grant["broker_thread"] == "01a10839-8042-7072-b744-1e54b8421800"
assert grant["supervisor_queue_sha256"] == sha256(queue_path)
assert grant["supervisor_action_sha256"] == sha256(Path(__file__))
assert grant["maximum_gpu_children"] == job["maximum_gpu_children"] == 1
assert (
    grant["packet_sha256"]
    == job["packet_sha256"]
    == "982cee4788b961f1bde1cd2ded2b3da2fcf18ac58c178f154744244c5f1441ba"
)
assert (
    grant["source_commit"]
    == job["source_commit"]
    == "b6cb215eb2092d51a13da79ef74e7a58c508d793"
)
assert grant["remote_root"] == spec["root"] == str(root)
assert spec["label"] == label and spec["status_relative"] == "evidence/controller.json"
assert (
    grant["boot_id"]
    == binding["boot_id"]
    == Path("/proc/sys/kernel/random/boot_id").read_text().strip()
)
assert grant["gpu_uuid"] == binding["gpu_uuid"]
assert time.time() < grant["admission_expires_unix"]
assert (
    sha256(supervisor / "flashrnn2-job-spec.json")
    == "185c999646ec87c026c8ced58caa790ed000c93b2f563baed6a82329db755a8a"
)
assert sha256(archive) == job["packet_sha256"]
assert (
    sha256(wrapper)
    == "922bbd3fa25386c00009bc94c994f4fed76f07b3dd26a9a42efdc10f62601615"
)
assert runtime.is_file() and os.access(runtime, os.X_OK)

manifest_path = root / "manifest.json"
assert (
    sha256(manifest_path)
    == "da1981ef0d1ff189c6c43c3d8e8989c15198e57aa837352674af2f5ccf938407"
)
manifest = json.loads(manifest_path.read_text())
assert manifest["source_commit"] == job["source_commit"]
assert manifest["runtime"].startswith(str(runtime))
assert len(manifest["files"]) == 119
for name, entry in manifest["files"].items():
    path = root / name
    assert path.stat().st_size == entry["bytes"] and sha256(path) == entry["sha256"], (
        name
    )
assert (
    sha256(root / "controller.py")
    == "2d2c77d8cbda8d964afb42ebdecd9b31be6fa5f82675e6d6f39f4e07164ef2f5"
)

hardware = subprocess.check_output(
    ["nvidia-smi", "--query-gpu=uuid,name,driver_version", "--format=csv,noheader"],
    text=True,
).strip()
assert hardware == manifest["gpu_identity"]
for identity in manifest["locks"]:
    lock = Path("/root/autodl-tmp/0z5a-coordination/h20") / identity["name"]
    stat = lock.stat()
    assert (stat.st_dev, stat.st_ino) == (identity["device"], identity["inode"])

launch = root / (label + "-launch.json")
assert not launch.exists() and not (root / (label + "-exit.json")).exists()
assert not (root / "evidence").exists()
command = [
    "/root/miniconda3/bin/python",
    str(wrapper),
    "--root",
    str(root),
    "--label",
    label,
    "--",
    str(runtime),
    str(root / "controller.py"),
]
with (root / (label + "-wrapper-console.log")).open("x") as output:
    process = subprocess.Popen(
        command,
        cwd=root,
        stdout=output,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )

for _ in range(600):
    if launch.exists():
        try:
            receipt = json.loads(launch.read_text())
        except json.JSONDecodeError:
            receipt = None
        if receipt is not None:
            assert receipt["wrapper"]["pid"] == process.pid
            assert receipt["command"] == [str(runtime), str(root / "controller.py")]
            print(json.dumps(receipt), flush=True)
            break
    if process.poll() is not None:
        raise RuntimeError("wrapper ended before launch receipt")
    time.sleep(0.05)
else:
    raise RuntimeError("launch receipt missing; inspect before any new decision")
