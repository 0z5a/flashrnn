"""Record a finite controller's actual wait status, surviving SSH disconnects.

This metadata wrapper launches the unchanged admitted controller exactly once.
It does not signal any process or change the controller's GPU process budget.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def identity(pid):
    root = Path('/proc') / str(pid)
    return {'pid': pid, 'start_ticks': int((root / 'stat').read_text().rsplit(')', 1)[1].split()[19]),
            'command': (root / 'cmdline').read_bytes().replace(b'\0', b' ').decode()}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--label', required=True)
    p.add_argument('command', nargs=argparse.REMAINDER)
    args = p.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    if not command:
        p.error('controller command required')
    launch = args.root / (args.label + '-launch.json')
    terminal = args.root / (args.label + '-exit.json')
    log = args.root / (args.label + '-console.log')
    if launch.exists() or terminal.exists() or log.exists():
        raise RuntimeError('refuse repeated launch or receipt overwrite')
    receipt = {'started_unix': time.time(), 'wrapper': identity(os.getpid()), 'command': command}
    with log.open('x') as output:
        child = subprocess.Popen(command, cwd=args.root, stdout=output, stderr=subprocess.STDOUT)
        receipt['controller'] = identity(child.pid)
        with launch.open('x') as stream:
            json.dump(receipt, stream, indent=2)
        actual_code = child.wait()  # No timeout or termination.
    receipt.update(finished_unix=time.time(), actual_exit_code=actual_code,
                   controller_absent_after_wait=not (Path('/proc') / str(child.pid)).exists())
    with terminal.open('x') as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt), flush=True)
    return actual_code


if __name__ == '__main__':
    sys.exit(main())
