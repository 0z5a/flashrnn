import json,hashlib,shutil,subprocess,os,time,tarfile
from pathlib import Path
out=Path('/root/autodl-tmp/0z5a/flashrnn2-postrun-20261006');r=out/'payload';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=out/'audit_portable.py';assert h(a)=='402f6f3b68718394246168ca2b8a50b33adc2536c620a143f127f820aea4e13c'
f=out/'frozen-audit-sources';assert not f.exists();f.mkdir()
meta=json.loads((r/'evidence/portable-cuda-r3.meta.json').read_text());source=json.loads((r/'manifest.json').read_text())['files'];mapping={}
for i,(name,digest) in enumerate(meta['source_sha256'].items()):
 relative=str(Path(name).relative_to('/root/autodl-tmp/0z5a/flashrnn2-h20-portable-r3'));assert source[relative]['sha256']==h(r/relative)==digest
 filename=f'{i:03d}.py';shutil.copy2(r/relative,f/filename);mapping[name]={'file':filename,'sha256':digest}
(f/'manifest.json').write_text(json.dumps(mapping,indent=2)+'\n')
controller=r/'evidence/controller.json';derived=r/'evidence/portable-cuda-r3-controller.json';assert not derived.exists();shutil.copy2(controller,derived)
(out/'derived-controller-provenance.json').write_text(json.dumps({'original_path':'payload/evidence/controller.json','derived_path':'payload/evidence/portable-cuda-r3-controller.json','sha256':h(controller),'derived_sha256':h(derived),'original_unchanged':True},indent=2)+'\n')
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
command=['/root/autodl-tmp/0z5a/flashns-baselines-region42-35679-20261006/.venv/bin/python',str(a),str(r/'evidence/portable-cuda-r3.jsonl'),'--frozen-sources',str(f)]
with (out/'cpu-audit-console.log').open('xb') as log:
 process=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,env=env);pid=process.pid
 ticks=int(Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19]);started=time.time()
 (out/'cpu-audit-launch.json').write_text(json.dumps({'pid':pid,'start_ticks':ticks,'started_unix':started,'command':command,'CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','auditor_sha256':h(a)},indent=2)+'\n')
 rc=process.wait()
(out/'cpu-audit-exit.json').write_text(json.dumps({'pid':pid,'start_ticks':ticks,'started_unix':started,'finished_unix':time.time(),'actual_exit_code':rc,'absent_after_wait':not Path(f'/proc/{pid}').exists()},indent=2)+'\n')
assert rc==0,(out/'cpu-audit-console.log').read_text()
result=json.loads((r/'evidence/portable-cuda-r3-audit.json').read_text());assert result['audit']=='PASS' and result['passed']==result['cases']==38 and result['tensor_comparison_pairs']==456 and result['per_state_comparisons']==176
files={str(p.relative_to(out)):h(p) for p in sorted(out.rglob('*')) if p.is_file()};(out/'audited-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
a=out.with_name(out.name+'-audited.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
print(json.dumps({'archive':str(a),'archive_sha256':h(a),'archive_bytes':a.stat().st_size,'manifest_files':len(files),'actual_audit_exit_code':rc,'audit':result}),flush=True)
