import json,hashlib,os,fcntl,subprocess,time
from pathlib import Path
out=Path('/root/autodl-tmp/0z5a/flashrnn2-postrun-20261006');ns=Path('/root/autodl-tmp/0z5a/flashns-baselines-region42-35679-20261006');r=Path('/root/autodl-tmp/0z5a/flashrnn2-h20-portable-r3');s=ns/'remote-supervisor-20261006';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();b=json.loads((s/'queue.json').read_text())['resource_binding']
audit=json.loads((out/'cpu-audit-exit.json').read_text());assert audit['actual_exit_code']==0
actors=[45959,45962,45963,45968,audit['pid']];assert all(not Path(f'/proc/{p}').exists() for p in actors)
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==b['boot_id']
assert subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).strip()==b['gpu_uuid']
fds=[];locks=[]
try:
 for name,inode in zip(['gpu0.lock','io.lock'],b['lock_inodes']):
  fd=os.open('/root/autodl-tmp/0z5a-coordination/h20/'+name,os.O_RDWR);st=os.fstat(fd);assert(st.st_dev,st.st_ino)==(b['lock_device'],inode);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);fds.append(fd);locks.append({'name':name,'device':st.st_dev,'inode':st.st_ino,'nonblocking_exclusive':True})
 assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
 frozen=json.loads((ns/'gpu-source-manifest.json').read_text())
 for p,v in frozen.items():assert h(ns/p)==v
 source=json.loads((r/'manifest.json').read_text())['files']
 for p,v in source.items():assert h(r/p)==v['sha256']
 clear={'actual_check_exit_code':0,'recorded_unix':time.time(),'boot_id':b['boot_id'],'gpu_uuid':b['gpu_uuid'],'compute_apps':[],'locks':locks,'actors':[{'pid':p,'absent':True} for p in actors],'ns_original_source_files_verified':len(frozen),'rnn_source_files_verified':len(source)+1,'check_pid':os.getpid()}
 p=out/'fresh-clear.json';assert not p.exists();p.write_text(json.dumps(clear,indent=2)+'\n')
finally:
 for fd in reversed(fds):os.close(fd)
print(json.dumps(clear),flush=True)
