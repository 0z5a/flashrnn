import json,hashlib,shutil,tarfile,time,os,fcntl,subprocess
from pathlib import Path
r=Path('/root/autodl-tmp/0z5a/flashrnn2-h20-portable-r3');ns=Path('/root/autodl-tmp/0z5a/flashns-baselines-region42-35679-20261006');s=ns/'remote-supervisor-20261006';out=Path('/root/autodl-tmp/0z5a/flashrnn2-postrun-20261006')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
b=json.loads((s/'queue.json').read_text())['resource_binding']
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==b['boot_id']
exit=json.loads((r/'flashrnn2-portable-r3-exit.json').read_text());c=json.loads((r/'evidence/controller.json').read_text())
assert exit['actual_exit_code']==c['returncode']==0 and c['status']=='LOCKS_RELEASED'
actors=[exit['wrapper']['pid'],exit['controller']['pid'],c['child_pid'],45959]
assert all(not Path('/proc/'+str(p)).exists() for p in actors)
assert not out.exists();out.mkdir()
fds=[]
try:
 for name,inode in zip(['gpu0.lock','io.lock'],b['lock_inodes']):
  fd=os.open('/root/autodl-tmp/0z5a-coordination/h20/'+name,os.O_RDWR);st=os.fstat(fd);assert(st.st_dev,st.st_ino)==(b['lock_device'],inode);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);fds.append(fd)
 assert subprocess.check_output(['nvidia-smi','--query-gpu=uuid','--format=csv,noheader'],text=True).strip()==b['gpu_uuid']
 assert not subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader'],text=True).strip()
 manifest=json.loads((r/'manifest.json').read_text());assert len(manifest['files'])==119 and h(r/'manifest.json')=='da1981ef0d1ff189c6c43c3d8e8989c15198e57aa837352674af2f5ccf938407'
 for name,v in manifest['files'].items():assert h(r/name)==v['sha256'] and (r/name).stat().st_size==v['bytes']
 rows=[json.loads(x) for x in (r/'evidence/portable-cuda-r3.jsonl').read_text().splitlines()];assert len(rows)==38
 pts=sorted((r/'evidence/portable-cuda-r3.tensors').glob('*.pt'));assert len(pts)==38
 for i,row in enumerate(rows):assert row['tensors']==f'{i:03d}.pt' and h(pts[i])==row['tensor_sha256']
 frozen=json.loads((ns/'gpu-source-manifest.json').read_text())
 for name,v in frozen.items():assert h(ns/name)==v
 assert h(ns/'natural_exit_wrapper.py')=='922bbd3fa25386c00009bc94c994f4fed76f07b3dd26a9a42efdc10f62601615'
 shutil.copytree(r,out/'payload')
 (out/'supervisor').mkdir()
 for name in ['queue.json','supervisor.py','flashrnn2-job-spec.json','flashrnn2-stage.json','flashrnn2-grant.json','flashrnn2-action.py','flashrnn2-activation.json','flashrnn2-consumed.json','flashrnn2-action.log','status.json']:
  shutil.copy2(s/name,out/'supervisor'/name)
 shutil.copy2(ns/'gpu-source-manifest.json',out/'ns-original-source-manifest.json');shutil.copy2(ns/'natural_exit_wrapper.py',out/'natural_exit_wrapper.py')
 receipt={'recorded_unix':time.time(),'actual_collect_exit_code':0,'resource_binding':b,'source_files_verified':120,'ns_source_files_verified':len(frozen),'raw_cases':38,'tensor_files':38,'actors':[{ 'pid':p,'absent':True} for p in actors],'controller_actual_exit_code':0,'wrapper_actual_exit_code':0,'performance':'UNMEASURED'}
 (out/'raw-collection.json').write_text(json.dumps(receipt,indent=2)+'\n')
finally:
 for fd in reversed(fds):os.close(fd)
files={str(p.relative_to(out)):h(p) for p in sorted(out.rglob('*')) if p.is_file()};(out/'raw-manifest.json').write_text(json.dumps(files,indent=2)+'\n')
a=out.with_name(out.name+'-raw.tar.gz');assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for p in sorted(out.rglob('*')):
  if p.is_file():t.add(p,arcname=str(p.relative_to(out)),recursive=False)
print(json.dumps({'archive':str(a),'archive_sha256':h(a),'archive_bytes':a.stat().st_size,'manifest_files':len(files),'actual_exit_code':0}),flush=True)
