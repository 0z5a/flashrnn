"""Run three admitted H20 stacked-model cases sequentially, with natural exits."""

import argparse
import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path


def digest(path: Path) -> str:
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def gpu_snapshot() -> tuple[str, str]:
    hardware = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=uuid,name,driver_version", "--format=csv,noheader"],
        text=True,
    ).strip()
    compute = subprocess.check_output(
        ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader,nounits"],
        text=True,
    ).strip()
    return hardware, compute


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--grant", required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    job = json.loads((root / "job.json").read_text())
    manifest = json.loads((root / "manifest.json").read_text())
    grant = json.loads(args.grant.read_text())
    assert str(root) == job["remote_root"] == grant["remote_root"]
    assert sys.executable == job["runtime"] == grant["runtime"]
    assert manifest["source_commit"] == grant["source_commit"]
    assert digest(root / "manifest.json") == grant["manifest_sha256"]
    assert digest(root / "job.json") == grant["job_sha256"]
    assert digest(Path(__file__)) == grant["controller_sha256"]
    assert grant["state"] == "NEW_FINITE_WINDOW_GRANTED"
    assert grant["phase"] == "stacked_e2e"
    assert (
        grant["maximum_gpu_children"]
        == job["maximum_gpu_children"]
        == len(job["cases"])
        == 3
    )
    assert grant["maximum_concurrent_gpu_children"] == 1
    assert time.time() < grant["admission_expires_unix"]
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    assert boot == job["boot_id"] == grant["boot_id"]
    assert grant["gpu_uuid"] == job["gpu_uuid"]
    for name, entry in manifest["files"].items():
        path = root / name
        assert (
            path.stat().st_size == entry["bytes"] and digest(path) == entry["sha256"]
        ), name
    output = root / "evidence"
    output.mkdir()
    receipt = output / "controller.json"
    record = {
        "status": "PRECHECK",
        "controller_pid": os.getpid(),
        "started": time.time(),
        "grant_sha256": digest(args.grant),
        "manifest_sha256": digest(root / "manifest.json"),
        "source_commit": manifest["source_commit"],
        "children": [],
    }
    receipt.write_text(json.dumps(record, indent=2) + "\n")
    lock_dir = Path(job["lock_directory"])
    with (
        (lock_dir / "gpu0.lock").open("r") as gpu,
        (lock_dir / "io.lock").open("r") as io,
    ):
        for handle, identity in zip((gpu, io), job["locks"], strict=True):
            stat = os.fstat(handle.fileno())
            assert (stat.st_dev, stat.st_ino) == (identity["device"], identity["inode"])
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        hardware, compute = gpu_snapshot()
        assert hardware == job["gpu_identity"] and not compute, (hardware, compute)
        env = dict(os.environ, **job["environment"])
        for key in ("TRITON_CACHE_DIR", "CUDA_CACHE_PATH"):
            Path(env[key]).mkdir(parents=True)
        record.update(status="ADMITTED", hardware=hardware, admitted=time.time())
        receipt.write_text(json.dumps(record, indent=2) + "\n")
        for case in job["cases"]:
            command = [
                sys.executable,
                str(root / "application/tools/flashrnn2/stacked_e2e.py"),
                *case["args"],
                "--output",
                str(output / f"{case['id']}.jsonl"),
            ]
            with (output / f"{case['id']}.log").open("x") as log:
                child = subprocess.Popen(
                    command,
                    cwd=root / "application",
                    env=env,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                )
                start_ticks = int(
                    (Path("/proc") / str(child.pid) / "stat")
                    .read_text()
                    .rsplit(")", 1)[1]
                    .split()[19]
                )
                entry = {
                    "id": case["id"],
                    "pid": child.pid,
                    "start_ticks": start_ticks,
                    "command": command,
                    "started": time.time(),
                }
                record.update(status="RUNNING", current=entry)
                receipt.write_text(json.dumps(record, indent=2) + "\n")
                entry.update(returncode=child.wait(), finished=time.time())
            record["children"].append(entry)
            record.pop("current")
            hardware, compute = gpu_snapshot()
            assert hardware == job["gpu_identity"] and not compute, (hardware, compute)
            record.update(status="CASE_EXITED", hardware=hardware)
            receipt.write_text(json.dumps(record, indent=2) + "\n")
    record.update(
        status="LOCKS_RELEASED",
        finished=time.time(),
        all_cases_passed=all(case["returncode"] == 0 for case in record["children"]),
    )
    receipt.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    return 0 if record["all_cases_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
